package com.gisfy.unauthorizedlayouts.Profile;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.gisfy.unauthorizedlayouts.R;

public class GuideMe extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guide_me);
    }
}
