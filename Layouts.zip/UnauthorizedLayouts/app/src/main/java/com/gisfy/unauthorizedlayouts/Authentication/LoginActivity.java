package com.gisfy.unauthorizedlayouts.Authentication;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.widget.NestedScrollView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.gisfy.unauthorizedlayouts.BottomNavigation.NavigationView;
import com.gisfy.unauthorizedlayouts.Profile.Splash_Activity;
import com.gisfy.unauthorizedlayouts.R;
import com.gisfy.unauthorizedlayouts.Util.SessionManagement;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class LoginActivity extends AppCompatActivity {
    private EditText email, password;
    private CardView login_button;
    SessionManagement sessionManagement;
    ImageView img;
    Animation animtop,animbottom;
    CardView cardView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        setType();
        loginOnClick();
        img=findViewById(R.id.imageView);
        cardView=findViewById(R.id.cardView);
        animtop= AnimationUtils.loadAnimation(getApplicationContext(),
                R.anim.fromtop);
        img.setVisibility(View.VISIBLE);
        img.startAnimation(animtop);
        animbottom= AnimationUtils.loadAnimation(getApplicationContext(),
                R.anim.frombottom);
        cardView.setVisibility(View.VISIBLE);
        cardView.startAnimation(animbottom);
        sessionManagement=new SessionManagement(LoginActivity.this);
        if (sessionManagement.isLoggedIn())
        {
            startActivity(new Intent(LoginActivity.this, NavigationView.class));
        }
    }

    private void setType() {

        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        login_button = findViewById(R.id.login);

    }
    private void loginOnClick() {
        login_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (email.getText().length() == 0) {
                    email.setError("Be patience and enter Username");
                    email.requestFocus();
                } else if (password.getText().length() == 0) {
                    password.setError("Be patience and enter password");
                    password.requestFocus();
                } else {
                  ConstraintLayout cl = findViewById(R.id.login_layout);
                    ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                    if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED
                            || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED) {
                        final ProgressDialog progressDialog = new ProgressDialog(LoginActivity.this);
                        progressDialog.setMessage("Logging In...");
                        progressDialog.setCancelable(false);
                        progressDialog.show();
                        if (email.getText().length() > 0 && password.getText().length() > 0) {
                            final String credentials = "http://148.72.208.177/UMSAPI/api/UMS/LoginCheck?userid=" + email.getText().toString() + "&password=" + password.getText().toString();
                            StringRequest stringRequest = new StringRequest(Request.Method.GET, credentials,
                                    new Response.Listener<String>() {
                                        String empid;

                                        @Override
                                        public void onResponse(String response) {
                                            try {
                                                JSONArray jsonArray = new JSONArray(response);
                                                for (int i = 0; i < 1; i++) {
                                                    org.json.JSONObject jsonobject = jsonArray.getJSONObject(i);
                                                    progressDialog.dismiss();
                                                    empid = String.valueOf(jsonobject.getInt("employeeid"));
                                                }
                                                if (!(empid == null)) {
                                                    profiledata(empid);
                                                    sessionManagement.createLoginSession(email.getText().toString(), password.getText().toString());
                                                    startActivity(new Intent(LoginActivity.this, Splash_Activity.class));
                                                }

                                            } catch (JSONException ex) {
                                                progressDialog.dismiss();
                                                ex.printStackTrace();
                                                Toast.makeText(LoginActivity.this, "No User Found", Toast.LENGTH_SHORT).show();
                                            }

                                        }
                                    },
                                    new Response.ErrorListener() {
                                        @Override
                                        public void onErrorResponse(VolleyError error) {
                                            Toast.makeText(getApplicationContext(), "No Network or Maintenance problem", Toast.LENGTH_SHORT).show();
                                        }
                                    });

                            //creating a request queue
                            RequestQueue requestQueue = Volley.newRequestQueue(LoginActivity.this);
                            requestQueue.add(stringRequest);
                        } else {
                            Toast.makeText(getApplicationContext(), "Please fill the details", Toast.LENGTH_SHORT).show();
                        }
                    } else if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.DISCONNECTED
                            || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.DISCONNECTED) {
                        Snackbar snackbar = Snackbar
                                .make(cl, "No Network Connection", Snackbar.LENGTH_LONG);
                        snackbar.setActionTextColor(Color.RED);
                        snackbar.show();
                    }

                }
            }
        });
    }
    private void profiledata(String empid) {
        StringRequest stringRequest = new StringRequest(Request.Method.GET, "http://148.72.208.177/UMSAPI/api/UMS/ProfileDetails?employeeid="+empid,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONArray jsonArray = new JSONArray(response);
                            for (int i = 0; i < 1; i++) {
                                JSONObject empobj = jsonArray.getJSONObject(i);
                                if (empobj==null)
                                {
                                    Toast.makeText(LoginActivity.this, "Wrong Credentials", Toast.LENGTH_SHORT).show();
                                }
                                SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref", MODE_PRIVATE);
                                SharedPreferences.Editor myEdit = sharedPreferences.edit();
                                myEdit.putString("employeeid", empobj.getString("employeeid"));
                                myEdit.putString("employeename", empobj.getString("employeename"));
                                myEdit.putString("designationname", empobj.getString("designationname"));
                                myEdit.putString("emailid", empobj.getString("emailid"));
                                myEdit.putString("ulbname", empobj.getString("ulbname"));

                                myEdit.putInt("employeeid", empobj.getInt("employeeid"));
                                myEdit.putString("phoneno", empobj.getString("phoneno"));
                                myEdit.putInt("ulbcode", empobj.getInt("ulbcode"));
                                myEdit.putInt("designationid", empobj.getInt("designationid"));
                                myEdit.putString("userid", empobj.getString("userid"));
                                Log.i("json values","");
                                myEdit.commit();
                            }
                        } catch (JSONException ex) {
                            ex.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //displaying the error in toast if occurrs
                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });

        //creating a request queue
        RequestQueue requestQueue = Volley.newRequestQueue(this);

        //adding the string request to request queue
        requestQueue.add(stringRequest);
    }
}
