package com.gisfy.unauthorizedlayouts.SQLite;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentTransaction;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.SQLException;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextWatcher;
import android.text.method.DigitsKeyListener;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.gisfy.unauthorizedlayouts.BottomNavigation.NavigationView;
import com.gisfy.unauthorizedlayouts.R;
import com.gisfy.unauthorizedlayouts.Util.ImageFilePath;
import com.gisfy.unauthorizedlayouts.Util.WorkaroundMapFragment;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polygon;
import com.google.android.gms.maps.model.PolygonOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.squareup.picasso.Picasso;

import net.cachapa.expandablelayout.ExpandableLayout;
import net.gotev.uploadservice.MultipartUploadRequest;
import net.gotev.uploadservice.UploadNotificationConfig;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import in.mayanknagwanshi.imagepicker.ImageSelectActivity;
import in.mayanknagwanshi.imagepicker.imagePicker.ImagePicker;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import pub.devrel.easypermissions.AfterPermissionGranted;
import pub.devrel.easypermissions.AppSettingsDialog;
import pub.devrel.easypermissions.EasyPermissions;
import studio.carbonylgroup.textfieldboxes.ExtendedEditText;
import studio.carbonylgroup.textfieldboxes.TextFieldBoxes;

import static android.Manifest.permission.ACCESS_NETWORK_STATE;
import static android.Manifest.permission.READ_PHONE_NUMBERS;
import static android.Manifest.permission.READ_PHONE_STATE;
import static android.Manifest.permission.READ_SMS;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

public class MainActivity extends AppCompatActivity implements EasyPermissions.PermissionCallbacks,
        EasyPermissions.RationaleCallbacks,  OnMapReadyCallback, GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener {
    private GoogleMap mMap;
    private GoogleApiClient googleApiClient;
    Marker mCurrLocationMarker;
    Spinner sDistrict, sUlb,noofplots;
    TextInputEditText evillage, eDno, eLocality, eStreetName, eDoorno, eExtent, ePlots, eOwner, eFathername, eAddress1, eNotes;
    TextInputEditText ePhoneno;
    TextInputLayout village, Dno, Locality, StreetName, Doorno, Extent, Plots, Owner, Fathername, Address1, Notes,Phoneno;
    ImageView uploadimage,uploadimage2,uploadimage3,uploadimage4;
    String path,path2,path3,path4;
    boolean flag = false;
    Location loc;
    Location location;
    LatLng latLng;
    SupportMapFragment mapFragment;
    double latit;
    double lngit;
    FusedLocationProviderClient client;
    TextView tvlat, draftsman;
    private static final String TAG = "MainActivity";
    private static final String[] LOCATION_AND_CONTACTS =
            {Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.READ_CONTACTS};
    private static final int RC_CAMERA_PERM = 123;
    private static final int RC_LOCATION_CONTACTS_PERM = 124;
    public static SQLiteHelper mSQLiteHelper;
    private GoogleMap.OnCameraIdleListener onCameraIdleListener;
    @SuppressLint("WrongThread")
    boolean district=true;
    boolean ulb=true;
    ScrollView mScrollView;
    int empID;

    private Polygon polygon = null;
    private List<LatLng> listLatLngs = new ArrayList<>();
    private List<Marker> listMarkers = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findViewByIds();
        Resources res = getResources();
        configureCameraIdle();
        SharedPreferences sh = getSharedPreferences("MySharedPref", MODE_PRIVATE);
        String empName = sh.getString("employeename", "");
        draftsman.setText(empName);
        empID=sh.getInt("employeeid",0);
        draftsman.setText(empName);


        mapFragment = (WorkaroundMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        mSQLiteHelper = new SQLiteHelper(this, "Layouts.sqlite", null, 1);
        mSQLiteHelper.queryData("CREATE TABLE IF NOT EXISTS Layouts(id INTEGER PRIMARY KEY AUTOINCREMENT, Draftsman VARCHAR, District VARCHAR, Ulb VARCHAR, Village VARCHAR, Sno VARCHAR, Locality VARCHAR, StreetName VARCHAR, DoorNo VARCHAR, Extent VARCHAR, Plots VARCHAR, OwnerName VARCHAR, FathersName VARCHAR,Address1 VARCHAR, PhoneNo VARCHAR, Latitude VARCHAR, Longitude VARCHAR, Notes VARCHAR, Employeeid VARCHAR,timestamp VARCHAR,imagepath VARCHAR,imageuniqueID VARCHAR,imagepath2 VARCHAR,imageuniqueID2 VARCHAR,imagepath3 VARCHAR,imageuniqueID3 VARCHAR,imagepath4 VARCHAR,imageuniqueID4 VARCHAR,noofplots VARCHAR,LatLngs VARCHAR)");
        client = LocationServices.getFusedLocationProviderClient(this);
        ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, getResources().getStringArray(R.array.District));
        sDistrict.setAdapter(adapter2);
        sUlb.findViewById(R.id.ulb);
        mScrollView = (ScrollView) findViewById(R.id.scrollview);


        ((WorkaroundMapFragment) getSupportFragmentManager().findFragmentById(R.id.map)).setListener(new WorkaroundMapFragment.OnTouchListener() {
            @Override
            public void onTouch() {
                mScrollView.requestDisallowInterceptTouchEvent(true);
            }
        });
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this,
                R.layout.spinner_layout,  getApplicationContext().getResources().getStringArray(R.array.District));
        sDistrict.setAdapter(adapter);
        ArrayAdapter<String> noofplota = new ArrayAdapter<String>(MainActivity.this,
                R.layout.spinner_layout,  getApplicationContext().getResources().getStringArray(R.array.Plots));
        noofplots.setAdapter(noofplota);
        sDistrict.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2,
                                       long arg3) {
                MainActivity mCtx = new MainActivity();
                if (arg2 == 0) {
                    String nothing[] = {"Select District First"};
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this,
                            R.layout.spinner_layout, nothing);
                    sUlb.setAdapter(adapter);
                    district=false;
                }
                else
                {
                    district=true;
                }
                if (arg2 == 1) {
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(arg1.getContext(), R.layout.spinner_layout, getApplicationContext().getResources().getStringArray(R.array.Kurnool));
                    adapter.setDropDownViewResource(R.layout.spinner_layout);
                    sUlb.setAdapter(adapter);
                }
                if (arg2 == 2) {
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(arg1.getContext(),R.layout.spinner_layout, getApplicationContext().getResources().getStringArray(R.array.Anantapur));
                    adapter.setDropDownViewResource(R.layout.spinner_layout);
                    sUlb.setAdapter(adapter);
                }

                if (arg2 == 3) {
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(arg1.getContext(), R.layout.spinner_layout, getApplicationContext().getResources().getStringArray(R.array.Guntur));
                    adapter.setDropDownViewResource(R.layout.spinner_layout);
                    sUlb.setAdapter(adapter);
                }
                if (arg2 == 4) {
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(arg1.getContext(), R.layout.spinner_layout, getApplicationContext().getResources().getStringArray(R.array.Prakasam));
                    adapter.setDropDownViewResource(R.layout.spinner_layout);
                    sUlb.setAdapter(adapter);
                }
                if (arg2 == 5) {
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(arg1.getContext(),R.layout.spinner_layout, getApplicationContext().getResources().getStringArray(R.array.WestGodavari));
                    adapter.setDropDownViewResource(R.layout.spinner_layout);
                    sUlb.setAdapter(adapter);
                }
                if (arg2 == 6) {
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(arg1.getContext(),R.layout.spinner_layout, getApplicationContext().getResources().getStringArray(R.array.YSRKadapa));
                    adapter.setDropDownViewResource(R.layout.spinner_layout);
                    sUlb.setAdapter(adapter);
                }
                if (arg2 == 7) {
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(arg1.getContext(), R.layout.spinner_layout, getApplicationContext().getResources().getStringArray(R.array.GreaterVishakapatanam));
                    adapter.setDropDownViewResource(R.layout.spinner_layout);
                    sUlb.setAdapter(adapter);
                }
                if (arg2 == 8) {
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(arg1.getContext(), R.layout.spinner_layout, getApplicationContext().getResources().getStringArray(R.array.Vizianagaram));
                    adapter.setDropDownViewResource(R.layout.spinner_layout);
                    sUlb.setAdapter(adapter);
                }
                if (arg2 == 9) {
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(arg1.getContext(), R.layout.spinner_layout, getApplicationContext().getResources().getStringArray(R.array.Krishna));
                    adapter.setDropDownViewResource(R.layout.spinner_layout);
                    sUlb.setAdapter(adapter);
                }
                if (arg2 == 10) {
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(arg1.getContext(), R.layout.spinner_layout, getApplicationContext().getResources().getStringArray(R.array.Srikakulam));
                    adapter.setDropDownViewResource(R.layout.spinner_layout);
                    sUlb.setAdapter(adapter);
                }
                if (arg2 == 11) {
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(arg1.getContext(), R.layout.spinner_layout, getApplicationContext().getResources().getStringArray(R.array.Chittoor));
                    adapter.setDropDownViewResource(R.layout.spinner_layout);
                    sUlb.setAdapter(adapter);
                }
                if (arg2 == 12) {
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(arg1.getContext(), R.layout.spinner_layout, getApplicationContext().getResources().getStringArray(R.array.EastGodavari));
                    adapter.setDropDownViewResource(R.layout.spinner_layout);
                    sUlb.setAdapter(adapter);
                }
                if (arg2 == 13) {
                    ArrayAdapter<String> adapter = new ArrayAdapter<String>(arg1.getContext(), R.layout.spinner_layout, getApplicationContext().getResources().getStringArray(R.array.Nellore));
                    adapter.setDropDownViewResource(R.layout.spinner_layout);
                    sUlb.setAdapter(adapter);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }
        });
        sUlb.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position==0)
                {
                    ulb=false;
                }
                else
                {
                    ulb=true;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                ulb=false;
            }
        });
        uploadimage.setOnClickListener(v -> cameraTask());

        Button submit = findViewById(R.id.submit);
        submit.setOnClickListener(v -> {
            if (district)
            {
                if (ulb)
                {
                    if (validate(evillage,village,20))
                    {
                        if (validate(eDno,Dno,50))
                        {
                            if (validate(eLocality,Locality,50))
                            {
                                if (validate(eStreetName,StreetName,50))
                                {

                                        if (validate(eExtent,Extent,6))
                                        {
                                            if (validate(ePlots,Plots,6))
                                            {

                                                if (validateAddress(eAddress1,Address1))
                                                {
                                                    if (validatePhone(ePhoneno,Phoneno))
                                                    {
                                                        if (path==null)
                                                        {
                                                            Toast.makeText(this, "Please Select Photo", Toast.LENGTH_SHORT).show();
                                                        }
                                                        else if (path2==null)
                                                        {
                                                            Toast.makeText(this, "Please Select Photo", Toast.LENGTH_SHORT).show();

                                                        }
                                                        else if (path3==null)
                                                        {
                                                            Toast.makeText(this, "Please Select Photo", Toast.LENGTH_SHORT).show();

                                                        }
                                                        else if (path4==null)
                                                        {
                                                            Toast.makeText(this, "Please Select Photo", Toast.LENGTH_SHORT).show();

                                                        }
                                                        else {
                                                                result();
                                                        }
                                                    }
                                                }
                                            }
                                        }

                                }
                            }
                        }
                    }
                }
                else
                {
                    Toast.makeText(this, "Select ULB", Toast.LENGTH_SHORT).show();
                    sUlb.requestFocusFromTouch();
                    sUlb.performClick();
                }
            }
            else
            {
                Toast.makeText(this, "Select Distrct", Toast.LENGTH_SHORT).show();
                sDistrict.requestFocusFromTouch();
                sDistrict.performClick();
            }

        });
    }

    public void result() {

        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setTitle("Do you want to save the data?");
        String timeStamp = "current_timestamp";
        String uploadId = UUID.randomUUID().toString();
        String uploadId2 = UUID.randomUUID().toString();
        String uploadId3 = UUID.randomUUID().toString();
        String uploadId4 = UUID.randomUUID().toString();
       String slocation= tvlat.getText().toString();
        String[] latlong = slocation.split(" ");
        double longitude = Double.parseDouble(latlong[0]);
        double latitude = Double.parseDouble(latlong[1]);
        builder.setPositiveButton("Save", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                try {
                    mSQLiteHelper.insertData(draftsman.getText().toString(), sDistrict.getSelectedItem().toString(), sUlb.getSelectedItem().toString(),
                            evillage.getText().toString(), eDno.getText().toString(), eLocality.getText().toString(), eStreetName.getText().toString(), eDoorno.getText().toString(),
                            eExtent.getText().toString(), ePlots.getText().toString(), eOwner.getText().toString(), eFathername.getText().toString(), eAddress1.getText().toString(),
                            ePhoneno.getText().toString(),String.valueOf(latitude),String.valueOf(longitude),
                            eNotes.getText().toString(), empID, timeStamp, path,uploadId,path2,uploadId2,path3,uploadId3,path4,uploadId4,noofplots.getSelectedItem().toString(),noofplots.getSelectedItem().toString());
                    Toast.makeText(MainActivity.this, "Added Success Fully", Toast.LENGTH_SHORT).show();
                    evillage.setText("");
                    eDno.setText("");
                    eLocality.setText("");
                    eStreetName.setText("");
                    eDoorno.setText("");
                    eExtent.setText("");
                    ePlots.setText("");
                    eOwner.setText("");
                    eFathername.setText("");
                    eAddress1.setText("");
                    ePhoneno.setText("");


                    eNotes.setText("");
                    uploadimage.setImageResource(R.drawable.ic_account_circle_black_24dp);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                finish();
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {

                dialog.dismiss();
                dialog.cancel();
                Toast.makeText(getApplicationContext(), "Please Add the Form",
                        Toast.LENGTH_SHORT).show();
            }
          });
        AlertDialog dialog = builder.create();
        dialog.show();

    }


public boolean validate(TextInputEditText editText,TextInputLayout layout,int count)
{
  boolean validation = false;
    if(editText.getText().length()<=0)
    {
       layout.setErrorEnabled(true);
        layout.setError("Mandate Field");
      requestFocus(editText);
return false;


    }
    else if (editText.getText().length()>count)
    {
        Toast.makeText(this, "Input cannot exceed the specified limit ", Toast.LENGTH_SHORT).show();
       layout.setErrorEnabled(true);
        layout.setError("Should be less than "+count);
        requestFocus(editText);
        return false;
    }


    else
    {
        validation=true;
       layout.setErrorEnabled(false);
        layout.setError(null);
        layout.clearFocus();



    }

    return true;

}
    private void requestFocus(View view) {
        if (view.requestFocus()) {
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        }
    }
    public boolean validateAddress(TextInputEditText editText,TextInputLayout layout)
    {
        boolean validation = false;
        if(editText.getText().length()<=0)
        {
            layout.setErrorEnabled(true);
            layout.setError("Mandate Field");
            requestFocus(editText);

        }
        else if (editText.getText().length()>100)
        {
            //Toast.makeText(this, "Input Should be les than 20 char", Toast.LENGTH_SHORT).show();
            layout.setErrorEnabled(true);
            layout.setError("Address Should be less than 100");
            requestFocus(editText);

        }
        else
        {
            validation=true;
            layout.setErrorEnabled(false);
            layout.setError(null);
        }

        return validation;
    }

    public boolean validatePhone(TextInputEditText editText,TextInputLayout layout)
    {
        boolean validation = false;
        if(editText.getText().length()==0)
        {
            layout.setErrorEnabled(true);
            layout.setError("Mandate Field");
            requestFocus(editText);

        }
        else if (editText.getText().length()!=10)
        {
            //Toast.makeText(this, "Input Should be les than 20 char", Toast.LENGTH_SHORT).show();
            layout.setErrorEnabled(true);
            layout.setError("Phone No Should be 10 digits");

            requestFocus(editText);

        }
        else
        {
            validation=true;
            layout.setError(null);
            layout.setErrorEnabled(false);
        }

        return validation;
    }
    private void findViewByIds() {
        tvlat = findViewById(R.id.loc_lat);
        noofplots=findViewById(R.id.noofplots);
        draftsman = findViewById(R.id.draftsman);
        sDistrict = findViewById(R.id.district);
        sUlb = findViewById(R.id.ulb);
        uploadimage = findViewById(R.id.profile_image);
        uploadimage2 = findViewById(R.id.profile_image2);
        uploadimage3 = findViewById(R.id.profile_image3);
        uploadimage4 = findViewById(R.id.profile_image4);
        evillage= findViewById(R.id.village);
        eDno= findViewById(R.id.sno);
         eLocality= findViewById(R.id.locality);
        eStreetName= findViewById(R.id.streetname);
         eDoorno= findViewById(R.id.doorno);
         eExtent= findViewById(R.id.extent);
         ePlots= findViewById(R.id.plots);
         eOwner= findViewById(R.id.owner);
         eFathername= findViewById(R.id.fathername);
         eAddress1= findViewById(R.id.address);
         ePhoneno= findViewById(R.id.phoneno);
         eNotes= findViewById(R.id.notes);
//////////////////////////////////////////////////
        village= findViewById(R.id.villageTextLayout);
        Dno= findViewById(R.id.surveyTextLayout);
        Locality= findViewById(R.id.localityTextLayout);
        StreetName= findViewById(R.id.streetnameTextLayout);
        Doorno= findViewById(R.id.doornoTextLayout);
        Extent= findViewById(R.id.extentLayout);
        Plots= findViewById(R.id.plotsTextLayout);
        Owner= findViewById(R.id.ownerTextLayout);
        Fathername= findViewById(R.id.fathernameTextLayout);
        Address1= findViewById(R.id.addressTextLayout);
        Phoneno= findViewById(R.id.phonenumberlayout);
        Notes= findViewById(R.id.noteslayout);

        evillage.setFilters(new InputFilter[]{new InputFilter.LengthFilter(20)});
        eDno.setFilters(new InputFilter[]{new InputFilter.LengthFilter(20)});
        eLocality.setFilters(new InputFilter[]{new InputFilter.LengthFilter(20)});
        eStreetName.setFilters(new InputFilter[]{new InputFilter.LengthFilter(20)});
        eDoorno.setFilters(new InputFilter[]{new InputFilter.LengthFilter(20)});
        eExtent.setFilters(new InputFilter[]{new InputFilter.LengthFilter(6)});
        ePlots.setFilters(new InputFilter[]{new InputFilter.LengthFilter(6)});
        eOwner.setFilters(new InputFilter[]{new InputFilter.LengthFilter(50)});
        eFathername.setFilters(new InputFilter[]{new InputFilter.LengthFilter(25)});
        eAddress1.setFilters(new InputFilter[]{new InputFilter.LengthFilter(50)});
        ePhoneno.setFilters(new InputFilter[]{new InputFilter.LengthFilter(10)});
        eNotes.setFilters(new InputFilter[]{new InputFilter.LengthFilter(100)});

    }

    public void setLocation(View view) {
        if (Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                Log.d("mylog", "Not granted");
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            } else
                requestLocation();
        } else
            requestLocation();
    }

    public void requestLocation() {

        flag = true;
        client.getLastLocation().addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if (location != null) {
                    loc = location;
                    latit = loc.getLatitude();
                    lngit = loc.getLongitude();
                    tvlat.setText(lngit+" "+latit);
                }
            }
        });
    }

    private void configureCameraIdle() {
        onCameraIdleListener = () -> {
            LatLng latLng = mMap.getCameraPosition().target;
            tvlat.setText(latLng.longitude +" " + latLng.latitude);
        };
    }


    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
        mMap.setOnCameraIdleListener(onCameraIdleListener);
        setGoogleMapClickListener();
        setGoogleMapLongClickListener();
        setPolygonClickListener();

        if (mCurrLocationMarker != null) {
            mCurrLocationMarker.remove();
        }
        //Place current location marker
        if (location != null) {
            latLng = new LatLng(location.getLatitude(), location.getLongitude());
            MarkerOptions markerOptions = new MarkerOptions();
            markerOptions.position(latLng);
            markerOptions.title("Current Position");
            mCurrLocationMarker = mMap.addMarker(markerOptions);
            mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
            mMap.animateCamera(CameraUpdateFactory.zoomTo(18));
        }
        if (googleApiClient != null) {
            LocationServices.FusedLocationApi.removeLocationUpdates(googleApiClient, (com.google.android.gms.location.LocationListener) this);
        }


        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.ACCESS_FINE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED) {
                buildGoogleApiClient();
                mMap.setMyLocationEnabled(true);
            }
        }
        else {
            buildGoogleApiClient();
            mMap.setMyLocationEnabled(true);
        }
        mMap.clear();
        try {
            mMap.setMyLocationEnabled(true);
        }
        catch (SecurityException e)
        {
            startActivity(new Intent(getApplicationContext(), NavigationView.class));
            Toast.makeText(this, "You can't proceed without GPS", Toast.LENGTH_SHORT).show();
        }
    }
    private void buildGoogleApiClient() {

        googleApiClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API).build();
        googleApiClient.connect();
    }

    @Override
    public void onConnected(@Nullable Bundle bundle)
    {
        final LocationManager manager = (LocationManager) getSystemService( Context.LOCATION_SERVICE );

        if ( !manager.isProviderEnabled( LocationManager.GPS_PROVIDER ) ) {
            buildAlertMessageNoGps();
        }
        else
        {
            if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            location = LocationServices.FusedLocationApi.getLastLocation(googleApiClient);
            LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());
           // tvlat.setText(location.getLongitude()+" "+location.getLatitude());

            CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(latLng, 18);
            mMap.animateCamera(cameraUpdate);
        }
    }
    private void buildAlertMessageNoGps() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("You can't proceed without GPS. want to enable it?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(@SuppressWarnings("unused") final DialogInterface dialog, @SuppressWarnings("unused") final int id) {
                        startActivity(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, @SuppressWarnings("unused") final int id) {
                        startActivity(new Intent(getApplicationContext(),NavigationView.class));
                    }
                });
        final AlertDialog alert = builder.create();
        alert.show();
    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }




    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this);
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    private boolean hasCameraPermission() {
        return EasyPermissions.hasPermissions(this, Manifest.permission.CAMERA);
    }

    private boolean hasLocationAndContactsPermissions() {
        return EasyPermissions.hasPermissions(this, LOCATION_AND_CONTACTS);
    }


    @AfterPermissionGranted(RC_CAMERA_PERM)
    public void cameraTask() {
        if (hasCameraPermission()) {
            Intent intent = new Intent(MainActivity.this, ImageSelectActivity.class);
            intent.putExtra(ImageSelectActivity.FLAG_COMPRESS, true);//default is true
            intent.putExtra(ImageSelectActivity.FLAG_CAMERA, true);//default is true
            intent.putExtra(ImageSelectActivity.FLAG_GALLERY, true);//default is true
            intent.putExtra(ImageSelectActivity.RESULT_FILE_PATH,true);
            startActivityForResult(intent, 1213);

        } else {
            // Ask for one permission
            EasyPermissions.requestPermissions(
                    this,
                    getString(R.string.rationale_camera),
                    RC_CAMERA_PERM,
                    Manifest.permission.CAMERA, WRITE_EXTERNAL_STORAGE);
        }
    }


    @AfterPermissionGranted(RC_LOCATION_CONTACTS_PERM)
    public void locationAndContactsTask() {
        if (hasLocationAndContactsPermissions()) {
            // Have permissions, do the thing!
            //Toast.makeText(this, "TODO: Location and Contacts things", Toast.LENGTH_LONG).show();
            requestLocation();
        } else {
            // Ask for both permissions
            EasyPermissions.requestPermissions(
                    this,
                    getString(R.string.rationale_location_contacts),
                    RC_LOCATION_CONTACTS_PERM,
                    LOCATION_AND_CONTACTS);
        }
    }


    @Override
    public void onPermissionsGranted(int requestCode, @NonNull List<String> perms) {
        Log.d(TAG, "onPermissionsGranted:" + requestCode + ":" + perms.size());
    }

    @Override
    public void onPermissionsDenied(int requestCode, @NonNull List<String> perms) {
        Log.d(TAG, "onPermissionsDenied:" + requestCode + ":" + perms.size());
        if (EasyPermissions.somePermissionPermanentlyDenied(this, perms)) {
            new AppSettingsDialog.Builder(this).build().show();
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == AppSettingsDialog.DEFAULT_SETTINGS_REQ_CODE) {
            String yes = "Yes";
            String no = "No";

            // Do something after user returned from app settings screen, like showing a Toast.
            Toast.makeText(
                    this,
                    getString(R.string.returned_from_app_settings_to_activity,
                            hasCameraPermission() ? yes : no,
                            hasLocationAndContactsPermissions() ? yes : no),
                    Toast.LENGTH_LONG)
                    .show();
        }
        try {


            switch (requestCode) {
                case 1213:
                    path = data.getStringExtra(ImageSelectActivity.RESULT_FILE_PATH);
                    //imgPath.setText(filePath);
                    Bitmap selectedImage = BitmapFactory.decodeFile(path);
//                    File f = new File(path);
//                    Picasso.get().load(f).into(uploadimage);
                    uploadimage.setImageBitmap(selectedImage);

                    break;
                case 2:
                    path2 = data.getStringExtra(ImageSelectActivity.RESULT_FILE_PATH);
                    //imgPath.setText(filePath);
                    Bitmap selectedImage2 = BitmapFactory.decodeFile(path2);
//                    File f2 = new File(path2);
//                    Picasso.get().load(f2).into(uploadimage2);
                    uploadimage2.setImageBitmap(selectedImage2);
                    break;
                case 3:
                    path3 = data.getStringExtra(ImageSelectActivity.RESULT_FILE_PATH);
                    //imgPath.setText(filePath);
                    Bitmap selectedImage3 = BitmapFactory.decodeFile(path3);
//                    File f3 = new File(path3);
//                    Picasso.get().load(f3).into(uploadimage3);
                    uploadimage3.setImageBitmap(selectedImage3);
                    break;
                case 4:
                    path4 = data.getStringExtra(ImageSelectActivity.RESULT_FILE_PATH);
                    //imgPath.setText(filePath);
                    Bitmap selectedImage4 = BitmapFactory.decodeFile(path4);
//                    File f4 = new File(path4);
//                    Picasso.get().load(f4).into(uploadimage4);
                    uploadimage4.setImageBitmap(selectedImage4);
                    break;
            }
        }
        catch (NullPointerException e)
        {
            Toast.makeText(this, "Select Image", Toast.LENGTH_SHORT).show();
        }
        catch (OutOfMemoryError e)
        {
            Toast.makeText(this, "Select Again", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRationaleAccepted(int requestCode) {
        Log.d(TAG, "onRationaleAccepted:" + requestCode);
    }

    @Override
    public void onRationaleDenied(int requestCode) {
        Log.d(TAG, "onRationaleDenied:" + requestCode);
    }

    public void tooglemap(View view) {
        ExpandableLayout expandableLayout=findViewById(R.id.expandable_layout_map);
//        expandableLayout.toggle(true);
        expandableLayout.toggle();
    }

    public void image2(View view) {
        Intent intent2 = new Intent(MainActivity.this, ImageSelectActivity.class);
        intent2.putExtra(ImageSelectActivity.FLAG_COMPRESS, true);//default is true
        intent2.putExtra(ImageSelectActivity.FLAG_CAMERA, true);//default is true
        intent2.putExtra(ImageSelectActivity.FLAG_GALLERY, true);//default is true
        intent2.putExtra(ImageSelectActivity.RESULT_FILE_PATH,true);
        startActivityForResult(intent2, 2);

    }

    public void image3(View view) {
        Intent intent3 = new Intent(MainActivity.this, ImageSelectActivity.class);
        intent3.putExtra(ImageSelectActivity.FLAG_COMPRESS, false);//default is true
        intent3.putExtra(ImageSelectActivity.FLAG_CAMERA, true);//default is true
        intent3.putExtra(ImageSelectActivity.FLAG_GALLERY, true);//default is true
        startActivityForResult(intent3, 3);

    }

    public void image4(View view) {
        Intent intent4 = new Intent(MainActivity.this, ImageSelectActivity.class);
        intent4.putExtra(ImageSelectActivity.FLAG_COMPRESS, false);//default is true
        intent4.putExtra(ImageSelectActivity.FLAG_CAMERA, true);//default is true
        intent4.putExtra(ImageSelectActivity.FLAG_GALLERY, true);//default is true
        startActivityForResult(intent4, 4);
    }
    @Override
    public void onBackPressed() {
        AlertDialog alertbox = new AlertDialog.Builder(this)
                .setMessage("Do you want to leave this page?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {

                    // do something when the button is clicked
                    public void onClick(DialogInterface arg0, int arg1) {
                        finish();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {


                    public void onClick(DialogInterface arg0, int arg1) {
                    }
                })
                .show();
    }

    public void connectPolygon(View view) {
        if(listLatLngs.isEmpty())
        {
            Snackbar snackbar= Snackbar.make(mScrollView,"Polygon Should be 3 or more",Snackbar.LENGTH_SHORT);
            snackbar.setActionTextColor(Color.RED);
            snackbar.show();
        }
        else {
            if (polygon != null)
                polygon.remove();
            PolygonOptions polygonOptions = new PolygonOptions().addAll(listLatLngs).clickable(true);
            polygon = mMap.addPolygon(polygonOptions);
        }

    }
    private void setPolygonClickListener(){
        mMap.setOnPolygonClickListener(e -> {
            Snackbar.make(mScrollView, "Polygon clicked!"+polygon, Snackbar.LENGTH_SHORT).show();
        });
    }

    private void setGoogleMapClickListener(){
        mMap.setOnMapClickListener(e -> {
            MarkerOptions markerOptions = new MarkerOptions().position(e);
            Marker marker = mMap.addMarker(markerOptions);
            listMarkers.add(marker);
            listLatLngs.add(e);
        });
    }
    private void setGoogleMapLongClickListener(){
        mMap.setOnMapLongClickListener(e -> {
            if (polygon != null) polygon.remove();
            for (Marker marker : listMarkers) marker.remove();
            listMarkers.clear();
            listLatLngs.clear();
        });
    }
}