package com.gisfy.unauthorizedlayouts.BottomNavigation;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import com.gisfy.unauthorizedlayouts.BottomNavigation.adapter.BottomAdapter;
import com.gisfy.unauthorizedlayouts.BottomNavigation.design.BadgeBottomNavigtion;
import com.gisfy.unauthorizedlayouts.BottomNavigation.model.BottomItem;
import com.gisfy.unauthorizedlayouts.DashBoard;
import com.gisfy.unauthorizedlayouts.Profile.GuideMe;
import com.gisfy.unauthorizedlayouts.Profile.Help;
import com.gisfy.unauthorizedlayouts.Profile.Profile;
import com.gisfy.unauthorizedlayouts.Profile.aboutus;
import com.gisfy.unauthorizedlayouts.R;

import java.util.List;

import pub.devrel.easypermissions.AfterPermissionGranted;
import pub.devrel.easypermissions.AppSettingsDialog;
import pub.devrel.easypermissions.EasyPermissions;

public class NavigationView extends AppCompatActivity implements BottomAdapter.BottomItemClickInterface, EasyPermissions.PermissionCallbacks,
        EasyPermissions.RationaleCallbacks {
    private BadgeBottomNavigtion badgeBottomNavigtion;
    Fragment fragment;
    private final int HOME = 0;
    private final int PROFILE = 1;
    private final int ABOUT = 2;
    private final int HELP=3;
    private int selectedId = 0;
    AlertDialog dialog;
    private static final String[] LOCATION_AND_CONTACTS =
            {Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.READ_CONTACTS};

    private static final int RC_CAMERA_PERM = 123;
    private static final int RC_LOCATION_CONTACTS_PERM = 124;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_navigation_view);
        badgeBottomNavigtion = new BadgeBottomNavigtion(findViewById(R.id.BottomNavigation), NavigationView.this, NavigationView.this);
        initBottomItems();
        locationAndContactsTask();
        cameraTask();
    }
    public void cameraTask() {
        if (hasCameraPermission()) {
            // Have permission, do the thing!
        } else {
            // Ask for one permission
            EasyPermissions.requestPermissions(
                    this,
                    getString(R.string.rationale_camera),
                    RC_CAMERA_PERM,
                    Manifest.permission.CAMERA);
        }
    }

    @AfterPermissionGranted(RC_LOCATION_CONTACTS_PERM)
    public void locationAndContactsTask() {
        if (hasLocationAndContactsPermissions()) {
            // Have permissions, do the thing!

        } else {
            // Ask for both permissions
            EasyPermissions.requestPermissions(
                    this,
                    getString(R.string.rationale_location_contacts),
                    RC_LOCATION_CONTACTS_PERM,
                    LOCATION_AND_CONTACTS);
        }
    }
    @SuppressLint("ResourceType")
    private void initBottomItems() {
        BottomItem home = new BottomItem(HOME, R.drawable.home, "Home", true);
        BottomItem Profile = new BottomItem(PROFILE, R.drawable.ic_account_circle_black_24dp, "Profile", true);
        BottomItem About = new BottomItem(ABOUT, R.drawable.about, "About Us", false);
        BottomItem Help =new BottomItem(HELP,R.drawable.help,"Help", false);
        badgeBottomNavigtion.addBottomItem(home);
        badgeBottomNavigtion.addBottomItem(Profile);
        badgeBottomNavigtion.addBottomItem(About);
        badgeBottomNavigtion.addBottomItem(Help);
        badgeBottomNavigtion.apply(selectedId, getString(R.color.selectedColor), getString(R.color.unselectedColor));
        itemSelect(selectedId);
    }
    @Override
    public void onBackPressed() {

        final AlertDialog.Builder builder = new AlertDialog.Builder(NavigationView.this);
        builder.setMessage("Do you want to exit?");

        builder.setPositiveButton("Exit", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                moveTaskToBack(true);
                android.os.Process.killProcess(android.os.Process.myPid());
                System.exit(1);
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialog.dismiss();
            }
        });
        dialog=builder.create();
        dialog.show();

    }
    @Override
    public void itemSelect(int itemId)
    {

       switch(itemId)
       {
           case 0:
               fragment= new DashBoard();
                break;
           case 1:
               fragment = new Profile();
              break;
           case 2:
               fragment = new aboutus();
               break;
           case 3:
               fragment=new Help();
               break;
       }
        if (fragment != null) {
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.nav_host_fragment, fragment);
            ft.commit();
        }
    }

    public void guideme(View view) {
        startActivity(new Intent(NavigationView.this, GuideMe.class));
    }
    private boolean hasCameraPermission() {
        return EasyPermissions.hasPermissions(this, Manifest.permission.CAMERA);
    }

    private boolean hasLocationAndContactsPermissions() {
        return EasyPermissions.hasPermissions(this, Manifest.permission.ACCESS_FINE_LOCATION);
    }


    private boolean hasStoragePermission() {
        return EasyPermissions.hasPermissions(this, Manifest.permission.WRITE_EXTERNAL_STORAGE);
    }
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        // EasyPermissions handles the request result.
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this);
    }

    @Override
    public void onPermissionsGranted(int requestCode, @NonNull List<String> perms) {
        Log.d("granted", "onPermissionsGranted:" + requestCode + ":" + perms.size());
    }

    @Override
    public void onPermissionsDenied(int requestCode, @NonNull List<String> perms) {
        Log.d("granted", "onPermissionsDenied:" + requestCode + ":" + perms.size());

        // (Optional) Check whether the user denied any permissions and checked "NEVER ASK AGAIN."
        // This will display a dialog directing them to enable the permission in app settings.
        if (EasyPermissions.somePermissionPermanentlyDenied(this, perms)) {
            new AppSettingsDialog.Builder(this).build().show();
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == AppSettingsDialog.DEFAULT_SETTINGS_REQ_CODE) {
            String yes = "Yes";
            String no = "No";

            // Do something after user returned from app settings screen, like showing a Toast.
            Toast.makeText(
                    this,
                    getString(R.string.returned_from_app_settings_to_activity,
                            hasCameraPermission() ? yes : no,
                            hasLocationAndContactsPermissions() ? yes : no),
                    Toast.LENGTH_LONG)
                    .show();
        }
    }

    @Override
    public void onRationaleAccepted(int requestCode) {
        Log.d("Rationale perm", "onRationaleAccepted:" + requestCode);
    }

    @Override
    public void onRationaleDenied(int requestCode) {
        Log.d("Rationale perm", "onRationaleDenied:" + requestCode);
    }
}
