package com.gisfy.unauthorizedlayouts.Util;

public class Constants {
    public static final String UPLOAD_URL = "http://192.168.94.1/AndroidImageUpload/upload.php";
}
