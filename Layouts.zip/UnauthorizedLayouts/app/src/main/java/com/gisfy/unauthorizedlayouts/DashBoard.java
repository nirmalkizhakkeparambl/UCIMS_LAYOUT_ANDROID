package com.gisfy.unauthorizedlayouts;


import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.gisfy.unauthorizedlayouts.SQLite.MainActivity;

import com.gisfy.unauthorizedlayouts.SQLite.Model;
import com.gisfy.unauthorizedlayouts.SQLite.RecordListActivity;
import com.gisfy.unauthorizedlayouts.SQLite.SQLiteHelper;
import com.gisfy.unauthorizedlayouts.Util.SessionManagement;
import com.google.android.material.snackbar.Snackbar;


import net.gotev.uploadservice.MultipartUploadRequest;

import java.util.ArrayList;

import static android.content.Context.MODE_PRIVATE;

/**
 * A simple {@link Fragment} subclass.
 */
public class DashBoard extends Fragment {
SQLiteHelper mSQLiteHelper;
    ConstraintLayout cl;
    public DashBoard() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mSQLiteHelper = new SQLiteHelper(getContext(), "Layouts.sqlite", null, 1);
        mSQLiteHelper.queryData("CREATE TABLE IF NOT EXISTS Layouts(id INTEGER PRIMARY KEY AUTOINCREMENT, Draftsman VARCHAR, District VARCHAR, Ulb VARCHAR, Village VARCHAR, Sno VARCHAR, Locality VARCHAR, StreetName VARCHAR, DoorNo VARCHAR, Extent VARCHAR, Plots VARCHAR, OwnerName VARCHAR, FathersName VARCHAR,Address1 VARCHAR, PhoneNo VARCHAR, Latitude VARCHAR, Longitude VARCHAR, Notes VARCHAR, Employeeid VARCHAR,timestamp VARCHAR,imagepath VARCHAR,imageuniqueID VARCHAR,imagepath2 VARCHAR,imageuniqueID2 VARCHAR,imagepath3 VARCHAR,imageuniqueID3 VARCHAR,imagepath4 VARCHAR,imageuniqueID4 VARCHAR,noofplots VARCHAR,LatLngs VARCHAR)");

        View view= inflater.inflate(R.layout.fragment_dash_board, container, false);
        SharedPreferences sh = getActivity().getSharedPreferences("MySharedPref", MODE_PRIVATE);
        String empName = sh.getString("employeename", "");
        TextView email=view.findViewById(R.id.dash_email);
        if (!(empName==null)) {
            email.setText(empName);
        }
        ImageView add =view.findViewById(R.id.add);
        ImageView edit =view.findViewById(R.id.edit);
        ImageView sync=view.findViewById(R.id.sync);
        ImageView logout=view.findViewById(R.id.logout);
        cl=view.findViewById(R.id.dashboad_layout);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SessionManagement sessionManagement=new SessionManagement(getContext());
                sessionManagement.logoutUser();
                SharedPreferences sharedPreferences = getActivity().getSharedPreferences("MySharedPref", MODE_PRIVATE);
                SharedPreferences.Editor myEdit = sharedPreferences.edit();
                myEdit.clear();
            }
        });
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getContext(), MainActivity.class));
            }
        });
        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getContext(), RecordListActivity.class));
            }
        });
        sync.setOnClickListener(v -> {
            ConstraintLayout cl=view.findViewById(R.id.dashboad_layout);
            ConnectivityManager connectivityManager=(ConnectivityManager) getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
            if ( connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED
                    || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED ) {
                synchronisation();
            }
            else if ( connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.DISCONNECTED
                    || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.DISCONNECTED) {
                Snackbar snackbar = Snackbar
                        .make(cl, "No Network Connection", Snackbar.LENGTH_LONG);
                snackbar.setActionTextColor(Color.RED);
                snackbar.show();
            }

        });
        return view;

    }

    private void synchronisation() {
        ArrayList<Model> mList = new ArrayList<>();
        ProgressDialog pDialog=new ProgressDialog(getContext());
        mSQLiteHelper = new SQLiteHelper(getContext(), "Layouts.sqlite", null, 1);
        Cursor cursor =mSQLiteHelper.getData("SELECT * FROM Layouts");
        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            String Draftsman = cursor.getString(1);
            String District = cursor.getString(2);
            String Ulb = cursor.getString(3);
            String Village = cursor.getString(4);
            String Sno = cursor.getString(5);
            String Locality = cursor.getString(6);
            String Streetname = cursor.getString(7);
            String Dno = cursor.getString(8);
            String Extent = cursor.getString(9);
            String Plots = cursor.getString(10);
            String Owner = cursor.getString(11);
            String Fathername = cursor.getString(12);
            String Address1 = cursor.getString(13);
            String Phoneno = cursor.getString(14);
            String Latitude = String.valueOf(cursor.getDouble(15));
            String Longitude = String.valueOf(cursor.getDouble(16));
            String Notes = cursor.getString(17);
            int empid = Integer.parseInt(cursor.getString(18));
            String timestamp = cursor.getString(19);
            String ImagePath = cursor.getString(20);
            String uploadid = cursor.getString(21);
            String uploadid2 = cursor.getString(23);
            String uploadid3 = cursor.getString(25);
            String uploadid4 = cursor.getString(27);
            String noonfplots=cursor.getString(28);
            //add to list
            mList.add(new Model(Owner,Fathername,Phoneno));
            String Url = "http://148.72.208.177/UMSAPI/api/UMS?query=INSERT INTO public.\"tblUnauthorizedLayout\"(latitude, longitude,geom,\"WPRSBISAD\", \"Name\", \"FHName\", \"Address\", viltown, \"DoorNo\", locality, streetname, \"ULB\", district,imagepath, \"Extent\", \"Plots\", \"SurveyNo\", \"PhoneNo\", \"Note\",\"employeeid\",\"StartedDate\",\"roadType\",\"imagepath1\",\"imagepath2\",\"imagepath3\")VALUES(" +
                    "'" + Latitude +
                    "','" + Longitude +
                    "'," + "ST_GeomFromText('POINT(" + Longitude + " " + Latitude + ")',4326)" +
                    ",'" + Draftsman +
                    "','" + Owner +
                    "','" + Fathername +
                    "','" + Address1 +
                    "','" + Village +
                    "','" + Dno +
                    "','" + Locality +
                    "','" + Streetname +
                    "','" + Ulb +
                    "','" + District +
                    "','" + uploadid + ".jpg" +
                    "','" + Extent +
                    "','" + Plots +
                    "','" + Sno +
                    "','" + Phoneno +
                    "','" + Notes +
                    "'," + empid +
                    "," + timestamp +
                    ",'" + noonfplots +
                    "','" + uploadid2  + ".jpg"+
                    "','" + uploadid3  + ".jpg"+
                    "','" + uploadid4  + ".jpg"+"')";

            new MyTask(uploadid, ImagePath).execute(uploadid, ImagePath);

                pDialog.setMessage("Please wait! Your data is syncing..");
                pDialog.setCancelable(false);
                pDialog.show();
                RequestQueue queue = Volley.newRequestQueue(getContext());
                StringRequest stringRequest = new StringRequest(Request.Method.GET, Url,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                // Display the first 500 characters of the response string.
                                Log.i("succ", response.substring(0, 10));
                                String reponse = response.substring(0, 10);
                                Log.i("succ", response);
                                if (reponse.equals("\"inserted\"")) {
                                    pDialog.dismiss();
                                    mSQLiteHelper.deleteTable();
                                    Snackbar snackbar = Snackbar
                                            .make(cl, "Sync Success", Snackbar.LENGTH_LONG);
                                    snackbar.setActionTextColor(Color.RED);
                                    snackbar.show();
                                } else {
                                    pDialog.dismiss();

                                }
                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        pDialog.dismiss();
                        Snackbar snackbar = Snackbar
                                .make(cl, "Something went wrong", Snackbar.LENGTH_LONG);
                        snackbar.setActionTextColor(Color.RED);
                        snackbar.show();
                        Log.i("some volley err", String.valueOf(error));
                    }
                });
                queue.add(stringRequest);
        }
        if (mList.size()==0){
            Snackbar snackbar = Snackbar
                    .make(cl, "No Data Found..?", Snackbar.LENGTH_LONG)
                    .setAction("Add Now", new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            startActivity(new Intent(getActivity(), MainActivity.class));
                        }
                    });
            snackbar.setActionTextColor(Color.RED);
            snackbar.show();
        }
    }

    private class MyTaskResult {
        String text1;
        String text2;
    }
    private class MyTask extends AsyncTask<Object, Void, MyTaskResult> {
        private String val1;
        private String val2;



        public MyTask(String in3, String in4) {
            this.val1 = in3;
            this.val2 = in4;

            // Do something ...
        }

        protected void onPreExecute() {
            // Do something ...
        }

        @Override
        protected MyTaskResult doInBackground(Object... params) {
            MyTaskResult res = new MyTaskResult();
            val1 = (String) params[0];
            val2 = (String) params[1];
            try {
                Log.i("threadas",val1);
                new MultipartUploadRequest(getContext(), val1, "http://148.72.208.177/ImageUpload/api/ManipulateImage/Upload?imgname="+val1)
                        .addFileToUpload(val2, "image") //Adding file
                        .addParameter("name", val2) //Adding text parameter to the request
//                        .setNotificationConfig(new UploadNotificationConfig())
                        .setMaxRetries(2)
                        .startUpload(); //Starting the upload

            } catch (Exception exc) {
                Log.i("threadas", exc.getMessage());
            }
            return null;
        }

        @Override
        protected void onPostExecute(MyTaskResult res) {

        }
    }


}
