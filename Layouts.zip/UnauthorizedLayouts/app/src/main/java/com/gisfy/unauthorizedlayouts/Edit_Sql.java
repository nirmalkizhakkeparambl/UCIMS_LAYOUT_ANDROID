package com.gisfy.unauthorizedlayouts;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.text.InputFilter;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.gisfy.unauthorizedlayouts.BottomNavigation.NavigationView;
import com.gisfy.unauthorizedlayouts.SQLite.MainActivity;
import com.gisfy.unauthorizedlayouts.SQLite.Model;
import com.gisfy.unauthorizedlayouts.SQLite.RecordListActivity;
import com.gisfy.unauthorizedlayouts.SQLite.RecordListAdapter;
import com.gisfy.unauthorizedlayouts.SQLite.SQLiteHelper;
import com.gisfy.unauthorizedlayouts.Util.Spinnerhelper;
import com.gisfy.unauthorizedlayouts.Util.WorkaroundMapFragment;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.squareup.picasso.Picasso;

import net.cachapa.expandablelayout.ExpandableLayout;

import java.io.File;
import java.util.ArrayList;
import java.util.UUID;

import in.mayanknagwanshi.imagepicker.ImageSelectActivity;


public class Edit_Sql extends AppCompatActivity implements OnMapReadyCallback, GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener {

    TextView tvlat,draftsman;
    TextInputEditText eDno,svillage,eLocality,eStreetName,eDoorno,eExtent,ePlots,eOwner,eFathername,eAddress1,ePhoneno,eNotes;
    TextInputLayout village, Dno, Locality, StreetName, Doorno, Extent, Plots, Owner, Fathername, Address1, Notes,Phoneno;

    LinearLayout loc;
    ImageView PreviewImage,PreviewImage2,PreviewImage3,PreviewImage4;
    ExpandableLayout expandableLayout_map;

    Spinner sDistrict,sUlb,noofplots;
    FusedLocationProviderClient client;
    SQLiteHelper mSQLiteHelper;
    int position;
    ScrollView mScrollView;
    Location location;
    GoogleMap mMap;
    GoogleApiClient googleApiClient;
    Marker mCurrLocationMarker;
    LatLng latLng;
    private GoogleMap.OnCameraIdleListener onCameraIdleListener;
    double latit;
    double lngit;
    ArrayList<Model> mList;
    boolean district=true;
    boolean ulb=true;
    double Latitude;
    double Longitude;
    RecordListAdapter mAdapter = null;
    SupportMapFragment mapFragment;
    String picturePath,picturePath2,picturePath3,picturePath4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit__sql);
        findViewByIds();
        expandableLayout_map.collapse();
        mList = new ArrayList<>();
        mAdapter = new RecordListAdapter(this, R.layout.row, mList);
        client= LocationServices.getFusedLocationProviderClient(this);
        mSQLiteHelper = new SQLiteHelper(this, "Layouts.sqlite", null, 1);
        ArrayAdapter<String> noofplota = new ArrayAdapter<String>(Edit_Sql.this,
                R.layout.spinner_layout,  getApplicationContext().getResources().getStringArray(R.array.Plots));
        noofplots.setAdapter(noofplota);
        position = getIntent().getIntExtra("position",0);
        mapFragment = (WorkaroundMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.emap);
        mapFragment.getMapAsync(this);
        ((WorkaroundMapFragment) getSupportFragmentManager().findFragmentById(R.id.emap)).setListener(new WorkaroundMapFragment.OnTouchListener() {
            @Override
            public void onTouch() {
                mScrollView.requestDisallowInterceptTouchEvent(true);
            }
        });
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if ( connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED
                || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED ) {
            configureCameraIdle();
        }
        else
        {
            Toast.makeText(this, "Network is Required to use Map", Toast.LENGTH_SHORT).show();
        }
        Cursor c =mSQLiteHelper.getData("SELECT * FROM Layouts WHERE id="+position);
        mList.clear();
        ArrayAdapter<String> dist= new ArrayAdapter<String>(this,R.layout.spinner_layout,getResources().getStringArray(R.array.District));
        dist.setDropDownViewResource(R.layout.spinner_layout);
        sDistrict.setAdapter(dist);
        Spinnerhelper spinnerhelper=new Spinnerhelper(Edit_Sql.this);
        while (c.moveToNext()){
            int id = c.getInt(0);
            String Draftsman = c.getString(1);
            draftsman.setText(Draftsman);
            String District = c.getString(2);
            String Ulb = c.getString(3);
            SpinnerSelection(sDistrict,District);
            spinnerhelper.ulbspinnerselection(District,sUlb,Ulb,getApplicationContext());
            String Village = c.getString(4);
            svillage.setText(Village);
            String Sno = c.getString(5);
            eDno.setText(Sno);
            String Locality = c.getString(6);
            eLocality.setText(Locality);
            String Streetname = c.getString(7);
            eStreetName.setText(Streetname);
            String Dno = c.getString(8);
            eDoorno.setText(Dno);
            String Extent = c.getString(9);
            eExtent.setText(Extent);
            String Plots = c.getString(10);
            ePlots.setText(Plots);
            String Owner = c.getString(11);
            eOwner.setText(Owner);
            String Fathername = c.getString(12);
            eFathername.setText(Fathername);
            String Address1 = c.getString(13);
            eAddress1.setText(Address1);

            String Phoneno = c.getString(14);
            ePhoneno.setText(Phoneno);
            Latitude = c.getDouble(15);

            Longitude = c.getDouble(16);
            tvlat.setText(String.valueOf(Latitude));
            String Notes  = c.getString(17);
            eNotes.setText(Notes);
            picturePath = c.getString(20);
            picturePath2 = c.getString(22);
            picturePath3 = c.getString(24);
            picturePath4 = c.getString(26);



            try {

                File f = new File(picturePath);
                Picasso.get().load(f).into(PreviewImage);

                Bitmap selectedImage2 = BitmapFactory.decodeFile(picturePath2);
                PreviewImage2.setImageBitmap(selectedImage2);

                Bitmap selectedImage3 = BitmapFactory.decodeFile(picturePath3);
                PreviewImage3.setImageBitmap(selectedImage3);

                Bitmap selectedImage4 = BitmapFactory.decodeFile(picturePath4);
                PreviewImage4.setImageBitmap(selectedImage4);
            }
            catch (OutOfMemoryError e)
            {
                Toast.makeText(this, ""+ e.getMessage(), Toast.LENGTH_SHORT).show();
            }
            String snoofplots=c.getString(28);
            spinnernoofplots(noofplots,snoofplots);
        }
        loc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                client.getLastLocation().addOnSuccessListener(new OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(Location location) {
                        if (location != null) {
                            latit = location.getLatitude();
                            lngit = location.getLongitude();
                            tvlat.setText( String.valueOf(latit));


                        }
                    }
                });
            }
        });
    }
public void eSubmit(View view)
{
    if (district)
    {
        if (ulb)
        {
            if (validate(svillage,village,20))
            {
                if (validate(eDno,Dno,50))
                {
                    if (validate(eLocality,Locality,50))
                    {
                        if (validate(eStreetName,StreetName,50))
                        {

                            if (validate(eExtent,Extent,6))
                            {
                                if (validate(ePlots,Plots,6))
                                {

                                    if (validateAddress(eAddress1,Address1))
                                    {
                                        if (validatePhone(ePhoneno,Phoneno))
                                        {
                                            result();
                                        }

                                    }

                                }
                            }
                        }
                    }
                }
            }
        }
        else
        {
            Toast.makeText(this, "Select ULB", Toast.LENGTH_SHORT).show();
            sUlb.requestFocusFromTouch();
            sUlb.performClick();
        }
    }
    else
    {
        Toast.makeText(this, "Select Distrct", Toast.LENGTH_SHORT).show();
        sDistrict.requestFocusFromTouch();
        sDistrict.performClick();
    }
}



    public void result() {
        String slocation= tvlat.getText().toString();
        String[] latlong = slocation.split(" ");
        double longitude = Double.parseDouble(latlong[0]);
        double latitude = Double.parseDouble(latlong[1]);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Do you want to update the data?")
                .setCancelable(false)
                .setPositiveButton("Update", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                        try {
                            mSQLiteHelper.updateData(
                                    draftsman.getText().toString(),
                                    sDistrict.getSelectedItem().toString(),
                                    sUlb.getSelectedItem().toString(),
                                    svillage.getText().toString(),
                                    eDno.getText().toString(),
                                    eLocality.getText().toString(),
                                    eStreetName.getText().toString(),
                                    eDoorno.getText().toString(),
                                    eExtent.getText().toString(),
                                    ePlots.getText().toString(),
                                    eOwner.getText().toString(),
                                    eFathername.getText().toString(),
                                    eAddress1.getText().toString(),
                                    ePhoneno.getText().toString(),
                                    String.valueOf(latitude),
                                    String.valueOf(longitude),
                                    eNotes.getText().toString(),
                                    picturePath,
                                    picturePath2,
                                    picturePath3,
                                    picturePath4,
                                    noofplots.getSelectedItem().toString(),
                                    position);
                            Toast.makeText(getApplicationContext(), "Update Successfull", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(getBaseContext(), NavigationView.class));
                        } catch (Exception error)
                        {
                            Log.e("Update error", error.getMessage());
                            Toast.makeText(getApplicationContext(), "" + error.getMessage(), Toast.LENGTH_SHORT).show();
                            Log.i("sql er", error.getMessage());
                        }
                        updateRecordList();

                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        //  Action for 'NO' Button
                        dialog.dismiss();
                        dialog.cancel();
                        Toast.makeText(getApplicationContext(), "Please Add the Form",
                                Toast.LENGTH_SHORT).show();
                    }
                });
        AlertDialog dialog = builder.create();
        dialog.show();

    }

    public boolean validate(TextInputEditText editText,TextInputLayout layout,int count)
    {
        boolean validation = false;
        if(editText.getText().length()<=0)
        {
            layout.setErrorEnabled(true);
            layout.setError("Mandate Field");
            requestFocus(editText);
            return false;


        }
        else if (editText.getText().length()>count)
        {
            Toast.makeText(this, "Input cannot exceed the specified limit", Toast.LENGTH_SHORT).show();
            layout.setErrorEnabled(true);
            layout.setError("Should be less than "+count);
            requestFocus(editText);
            return false;
        }


        else
        {
            validation=true;
            layout.setErrorEnabled(false);
            layout.setError(null);
            layout.clearFocus();



        }

        return true;

    }
    private void requestFocus(View view) {
        if (view.requestFocus()) {
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        }
    }
    public boolean validateAddress(TextInputEditText editText,TextInputLayout layout)
    {
        boolean validation = false;
        if(editText.getText().length()<=0)
        {
            layout.setErrorEnabled(true);
            layout.setError("Mandate Field");
            requestFocus(editText);

        }
        else if (editText.getText().length()>100)
        {
            //Toast.makeText(this, "Input Should be les than 20 char", Toast.LENGTH_SHORT).show();
            layout.setErrorEnabled(true);
            layout.setError("Address Should be less than 100");
            requestFocus(editText);

        }
        else
        {
            validation=true;
            layout.setErrorEnabled(false);
            layout.setError(null);


        }

        return validation;
    }

    public boolean validatePhone(TextInputEditText editText,TextInputLayout layout)
    {
        boolean validation = false;
        if(editText.getText().length()==0)
        {
            layout.setErrorEnabled(true);
            layout.setError("Mandate Field");
            requestFocus(editText);

        }
        else if (editText.getText().length()!=10)
        {
            //Toast.makeText(this, "Input Should be les than 20 char", Toast.LENGTH_SHORT).show();
            layout.setErrorEnabled(true);
            layout.setError("Phone No Should be 10 digits");

            requestFocus(editText);

        }
        else
        {
            validation=true;
            layout.setError(null);
            layout.setErrorEnabled(false);
        }

        return validation;
    }

public void spinnernoofplots(Spinner mSpinner,String compareValue)
{
    ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.Plots, (R.layout.spinner_layout));
    adapter.setDropDownViewResource(R.layout.spinner_layout);
    mSpinner.setAdapter(adapter);
    int arg2=0;
    if (compareValue != null) {
        arg2 = adapter.getPosition(compareValue);
        mSpinner.setSelection(arg2);
    }
}
    public void SpinnerSelection(Spinner mSpinner, String compareValue)
    {
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.District, (R.layout.spinner_layout));
        adapter.setDropDownViewResource(R.layout.spinner_layout);
        mSpinner.setAdapter(adapter);
        int arg2=0;
        if (compareValue != null) {
            arg2 = adapter.getPosition(compareValue);
            mSpinner.setSelection(arg2);
        }
        if (arg2 == 1) {
            ArrayAdapter<String> kurnool = new ArrayAdapter<String>(Edit_Sql.this, R.layout.spinner_layout, getApplicationContext().getResources().getStringArray(R.array.Kurnool));
            adapter.setDropDownViewResource(R.layout.spinner_layout);
            sUlb.setAdapter(kurnool);
        }
        if (arg2 == 2) {
            ArrayAdapter<String> a2 = new ArrayAdapter<String>(Edit_Sql.this,R.layout.spinner_layout, getApplicationContext().getResources().getStringArray(R.array.Anantapur));
            adapter.setDropDownViewResource(R.layout.spinner_layout);
            sUlb.setAdapter(a2);
        }

        if (arg2 == 3) {
            ArrayAdapter<String> a3 = new ArrayAdapter<String>(Edit_Sql.this, R.layout.spinner_layout, getApplicationContext().getResources().getStringArray(R.array.Guntur));
            adapter.setDropDownViewResource(R.layout.spinner_layout);
            sUlb.setAdapter(a3);
        }
        if (arg2 == 4) {
            ArrayAdapter<String> a4 = new ArrayAdapter<String>(Edit_Sql.this,R.layout.spinner_layout, getApplicationContext().getResources().getStringArray(R.array.Prakasam));
            adapter.setDropDownViewResource(R.layout.spinner_layout);
            sUlb.setAdapter(a4);
        }
        if (arg2 == 5) {
            ArrayAdapter<String> a5 = new ArrayAdapter<String>(Edit_Sql.this, R.layout.spinner_layout, getApplicationContext().getResources().getStringArray(R.array.WestGodavari));
            adapter.setDropDownViewResource(R.layout.spinner_layout);
            sUlb.setAdapter(a5);
        }
        if (arg2 == 6) {
            ArrayAdapter<String> a6 = new ArrayAdapter<String>(Edit_Sql.this, R.layout.spinner_layout, getApplicationContext().getResources().getStringArray(R.array.YSRKadapa));
            adapter.setDropDownViewResource(R.layout.spinner_layout);
            sUlb.setAdapter(a6);
        }
        if (arg2 == 7) {
            ArrayAdapter<String> a7 = new ArrayAdapter<String>(Edit_Sql.this, R.layout.spinner_layout, getApplicationContext().getResources().getStringArray(R.array.GreaterVishakapatanam));
            adapter.setDropDownViewResource(R.layout.spinner_layout);
            sUlb.setAdapter(a7);
        }
        if (arg2 == 8) {
            ArrayAdapter<String> a8 = new ArrayAdapter<String>(Edit_Sql.this, R.layout.spinner_layout, getApplicationContext().getResources().getStringArray(R.array.Vizianagaram));
            adapter.setDropDownViewResource(R.layout.spinner_layout);
            sUlb.setAdapter(a8);
        }
        if (arg2 == 9) {
            ArrayAdapter<String> a9 = new ArrayAdapter<String>(Edit_Sql.this, R.layout.spinner_layout, getApplicationContext().getResources().getStringArray(R.array.Krishna));
            adapter.setDropDownViewResource(R.layout.spinner_layout);
            sUlb.setAdapter(a9);
        }
        if (arg2 == 10) {
            ArrayAdapter<String> a10 = new ArrayAdapter<String>(Edit_Sql.this,R.layout.spinner_layout, getApplicationContext().getResources().getStringArray(R.array.Srikakulam));
            adapter.setDropDownViewResource(R.layout.spinner_layout);
            sUlb.setAdapter(a10);
        }
        if (arg2 == 11) {
            ArrayAdapter<String> a11 = new ArrayAdapter<String>(Edit_Sql.this, R.layout.spinner_layout, getApplicationContext().getResources().getStringArray(R.array.Chittoor));
            adapter.setDropDownViewResource(R.layout.spinner_layout);
            sUlb.setAdapter(a11);
        }
        if (arg2 == 12) {
            ArrayAdapter<String> a12 = new ArrayAdapter<String>(Edit_Sql.this, R.layout.spinner_layout, getApplicationContext().getResources().getStringArray(R.array.EastGodavari));
            adapter.setDropDownViewResource(R.layout.spinner_layout);
            sUlb.setAdapter(a12);
        }
        if (arg2 == 13) {
            ArrayAdapter<String> a13 = new ArrayAdapter<String>(Edit_Sql.this, R.layout.spinner_layout, getApplicationContext().getResources().getStringArray(R.array.Nellore));
            adapter.setDropDownViewResource(R.layout.spinner_layout);
            sUlb.setAdapter(a13);
        }



    }

    private void updateRecordList() {
        //get all data from sqlite
        Cursor cursor = mSQLiteHelper.getData("SELECT * FROM Layouts");
        mList.clear();
        while (cursor.moveToNext()){

            String Owner = cursor.getString(11);
            String Fathername = cursor.getString(12);
            String Phoneno = cursor.getString(14);
            mList.add(new Model(Owner,Fathername,Phoneno));
        }
    }
    private void configureCameraIdle() {

        onCameraIdleListener = new GoogleMap.OnCameraIdleListener() {
            @Override
            public void onCameraIdle() {
                LatLng latLng = mMap.getCameraPosition().target;
                tvlat.setText(latLng.longitude+" "+latLng.latitude);
            }
        };
    }
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
        mMap.setOnCameraIdleListener(onCameraIdleListener);
        if (mCurrLocationMarker != null) {
            mCurrLocationMarker.remove();
        }
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if ( connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED
                || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED ) {
            if (location != null) {
                latLng = new LatLng(location.getLatitude(), location.getLongitude());
                MarkerOptions markerOptions = new MarkerOptions();
                markerOptions.position(latLng);
                markerOptions.title("Current Position");
                markerOptions.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN));
                mCurrLocationMarker = mMap.addMarker(markerOptions);
                mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
                mMap.animateCamera(CameraUpdateFactory.zoomTo(20));
            }
            if (googleApiClient != null) {
                LocationServices.FusedLocationApi.removeLocationUpdates(googleApiClient, (com.google.android.gms.location.LocationListener) this);
            }


            if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (ContextCompat.checkSelfPermission(this,
                        Manifest.permission.ACCESS_FINE_LOCATION)
                        == PackageManager.PERMISSION_GRANTED) {
                    buildGoogleApiClient();
                    mMap.setMyLocationEnabled(true);
                }
            } else {
                buildGoogleApiClient();
                mMap.setMyLocationEnabled(true);
            }

            mMap.clear();
            try {
                mMap.setMyLocationEnabled(true);
            }
            catch (SecurityException e)
            {
                startActivity(new Intent(getApplicationContext(),RecordListActivity.class));
                Toast.makeText(this, "You can't proceed without GPS", Toast.LENGTH_SHORT).show();

            }
        }
        else
        {
            Toast.makeText(this, "Network is Required to use Map ", Toast.LENGTH_SHORT).show();
        }
    }

    private void buildGoogleApiClient() {
        googleApiClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API).build();
        googleApiClient.connect();
    }

    @Override
    public void onConnected(@Nullable Bundle bundle)
    {
        final LocationManager manager = (LocationManager) getSystemService( Context.LOCATION_SERVICE );
        assert manager != null;
        if ( !manager.isProviderEnabled( LocationManager.GPS_PROVIDER ) ) {
            buildAlertMessageNoGps();
        }
        else
        {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Please Turn on Gps", Toast.LENGTH_SHORT).show();
        }


            LatLng latLng = new LatLng(Latitude, Longitude);
            CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(latLng, 20);
            //tvlat.setText(Longitude+","+Latitude);
            mMap.animateCamera(cameraUpdate);
        }
    }
    private void buildAlertMessageNoGps() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Your GPS seems to be disabled, do you want to enable it?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(@SuppressWarnings("unused") final DialogInterface dialog, @SuppressWarnings("unused") final int id) {
                        startActivity(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, @SuppressWarnings("unused") final int id) {

                        startActivity(new Intent(getApplicationContext(),RecordListActivity.class));
                    }
                });
        final AlertDialog alert = builder.create();
        alert.show();
    }
    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }
    private void findViewByIds() {
        expandableLayout_map=findViewById(R.id.eexpandable_layout_map);
        PreviewImage=findViewById(R.id.eprofile_image);
        PreviewImage2=findViewById(R.id.eprofile_image2);
        PreviewImage3=findViewById(R.id.eprofile_image3);
        PreviewImage4=findViewById(R.id.eprofile_image4);
        tvlat=findViewById(R.id.eloc_lat);
        noofplots=findViewById(R.id.enoofplots);
         draftsman=findViewById(R.id.edraftsman);
         sDistrict=findViewById(R.id.edistrict);
         sUlb=findViewById(R.id.eulb);
         svillage=findViewById(R.id.evillage);
         eDno=findViewById(R.id.esno);
         eLocality=findViewById(R.id.elocality);
         eStreetName=findViewById(R.id.estreetname);
        eDoorno=findViewById(R.id.edoorno);
         eExtent=findViewById(R.id.eextent);
         ePlots=findViewById(R.id.eplots);
         eOwner=findViewById(R.id.eowner);
         eFathername=findViewById(R.id.efathername);
         eAddress1=findViewById(R.id.eaddress);
         ePhoneno=findViewById(R.id.ephoneno);
        eNotes=findViewById(R.id.enotes);
        loc=findViewById(R.id.eloc);
        mScrollView=findViewById(R.id.escrollview);
        village=findViewById(R.id.evillageTextLayout);
        Dno=findViewById(R.id.esurveyTextLayout);
        Locality=findViewById(R.id.elocalityTextLayout);
        StreetName=findViewById(R.id.estreetnameTextLayout);
        Doorno=findViewById(R.id.edoornoTextLayout);
        Extent=findViewById(R.id.eextentLayout);
        Plots=findViewById(R.id.eplotsTextLayout);
        Owner=findViewById(R.id.eownerTextLayout);
        Fathername=findViewById(R.id.efathernameTextLayout);
        Address1=findViewById(R.id.eaddressTextLayout);
        Phoneno=findViewById(R.id.ephonenumberlayout);
        Notes=findViewById(R.id.enoteslayout);

        svillage.setFilters(new InputFilter[]{new InputFilter.LengthFilter(20)});
        eDno.setFilters(new InputFilter[]{new InputFilter.LengthFilter(20)});
        eLocality.setFilters(new InputFilter[]{new InputFilter.LengthFilter(20)});
        eStreetName.setFilters(new InputFilter[]{new InputFilter.LengthFilter(20)});
        eDoorno.setFilters(new InputFilter[]{new InputFilter.LengthFilter(20)});
        eExtent.setFilters(new InputFilter[]{new InputFilter.LengthFilter(6)});
        ePlots.setFilters(new InputFilter[]{new InputFilter.LengthFilter(6)});
        eOwner.setFilters(new InputFilter[]{new InputFilter.LengthFilter(50)});
        eFathername.setFilters(new InputFilter[]{new InputFilter.LengthFilter(25)});
        eAddress1.setFilters(new InputFilter[]{new InputFilter.LengthFilter(50)});
        ePhoneno.setFilters(new InputFilter[]{new InputFilter.LengthFilter(10)});
        eNotes.setFilters(new InputFilter[]{new InputFilter.LengthFilter(100)});
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        try {


            switch (requestCode) {

                case 1213:
                    if (resultCode == RESULT_OK) {
                        picturePath = data.getStringExtra(ImageSelectActivity.RESULT_FILE_PATH);
                        //imgPath.setText(filePath);
                        Bitmap selectedImage = BitmapFactory.decodeFile(picturePath);
//                        File f = new File(picturePath);
//                        Picasso.get().load(f).into(PreviewImage);
                        PreviewImage.setImageBitmap(selectedImage);
                    }
                    break;
                case 2:
                    if (resultCode == RESULT_OK) {
                        picturePath2 = data.getStringExtra(ImageSelectActivity.RESULT_FILE_PATH);
                        //imgPath.setText(filePath);
                        Bitmap selectedImage2 = BitmapFactory.decodeFile(picturePath2);
//                        File f2 = new File(picturePath2);
//                        Picasso.get().load(f2).into(PreviewImage2);
                        PreviewImage2.setImageBitmap(selectedImage2);
                    }
                    break;
                case 3:
                    if (resultCode == RESULT_OK) {
                        picturePath3 = data.getStringExtra(ImageSelectActivity.RESULT_FILE_PATH);
                        //imgPath.setText(filePath);
                        Bitmap selectedImage3 = BitmapFactory.decodeFile(picturePath3);
//                        File f3 = new File(picturePath3);
//                        Picasso.get().load(f3).into(PreviewImage3);
                        PreviewImage3.setImageBitmap(selectedImage3);
                    }
                    break;
                case 4:
                    picturePath4 = data.getStringExtra(ImageSelectActivity.RESULT_FILE_PATH);
                    //imgPath.setText(filePath);
                    Bitmap selectedImage4 = BitmapFactory.decodeFile(picturePath4);
//                    File f4 = new File(picturePath4);
//                    Picasso.get().load(f4).into(PreviewImage4);
                    PreviewImage4.setImageBitmap(selectedImage4);
                    break;
            }
        }
        catch (NullPointerException e)
        {
            Toast.makeText(this, "Please select Image", Toast.LENGTH_SHORT).show();
        }
        catch (OutOfMemoryError e)
        {
            Toast.makeText(this, "Select Again", Toast.LENGTH_SHORT).show();
        }

        }



    public void etooglemap(View view)
    {
        expandableLayout_map.toggle();
    }
    public void eprofile(View view)
    {
        Intent intent = new Intent(Edit_Sql.this, ImageSelectActivity.class);
        intent.putExtra(ImageSelectActivity.FLAG_COMPRESS, false);//default is true
        intent.putExtra(ImageSelectActivity.FLAG_CAMERA, true);//default is true
        intent.putExtra(ImageSelectActivity.FLAG_GALLERY, true);//default is true
        startActivityForResult(intent, 1213);
    }
    public void image2(View view) {
        Intent intent2 = new Intent(Edit_Sql.this, ImageSelectActivity.class);
        intent2.putExtra(ImageSelectActivity.FLAG_COMPRESS, false);//default is true
        intent2.putExtra(ImageSelectActivity.FLAG_CAMERA, true);//default is true
        intent2.putExtra(ImageSelectActivity.FLAG_GALLERY, true);//default is true
        intent2.putExtra(ImageSelectActivity.RESULT_FILE_PATH,true);
        startActivityForResult(intent2, 2);
    }

    public void image3(View view) {
        Intent intent3 = new Intent(Edit_Sql.this, ImageSelectActivity.class);
        intent3.putExtra(ImageSelectActivity.FLAG_COMPRESS, false);//default is true
        intent3.putExtra(ImageSelectActivity.FLAG_CAMERA, true);//default is true
        intent3.putExtra(ImageSelectActivity.FLAG_GALLERY, true);//default is true
        startActivityForResult(intent3, 3);
    }

    public void image4(View view) {
        Intent intent4 = new Intent(Edit_Sql.this, ImageSelectActivity.class);
        intent4.putExtra(ImageSelectActivity.FLAG_COMPRESS, false);//default is true
        intent4.putExtra(ImageSelectActivity.FLAG_CAMERA, true);//default is true
        intent4.putExtra(ImageSelectActivity.FLAG_GALLERY, true);//default is true
        startActivityForResult(intent4, 4);
    }
    @Override
    public void onBackPressed() {
        AlertDialog alertbox = new AlertDialog.Builder(this)
                .setMessage("Do you want to leave this page?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {

                    // do something when the button is clicked
                    public void onClick(DialogInterface arg0, int arg1) {

                        finish();



                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {


                    public void onClick(DialogInterface arg0, int arg1) {
                    }
                })
                .show();
    }
}
